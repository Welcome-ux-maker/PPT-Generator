# SlideForge - repaired

This version removes Composer/PHPPresentation and uses a dependency-free Open XML PPTX writer.

## Gemini setup
1. Open `config.php`.
2. Set `GEMINI_API_KEY` to your Gemini API key.
3. Text generation uses `gemini-3.8-flash`.
4. Slide image generation uses `gemini-3.1-flash-image` (Nano Banana 2).

The project does not use Wikipedia, Pexels/Pixabay, or Groq.

## PHP requirements
- PHP 8.x
- cURL extension enabled
- Either PHP Zip extension or the system `zip` command

If Windows/XAMPP reports a local issuer certificate error, the project can use the configured fallback for that specific cURL certificate failure. For production, configure a proper CA bundle instead.
