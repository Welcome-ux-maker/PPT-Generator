<?php
require_once __DIR__ . '/includes/functions.php';

$id = basename($_GET['id'] ?? '');
$project = find_project($id);
$file = PPTX_DIR . '/' . $id . '.pptx';

if (!$project || !file_exists($file)) {
    http_response_code(404);
    echo 'Deck not found.';
    exit;
}

$filename = slugify($project['title']) . '.pptx';

header('Content-Description: File Transfer');
header('Content-Type: application/vnd.openxmlformats-officedocument.presentationml.presentation');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . filesize($file));
header('Cache-Control: must-revalidate');
readfile($file);
exit;
