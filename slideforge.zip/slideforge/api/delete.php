<?php
require_once __DIR__ . '/../includes/functions.php';

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$id = basename($input['id'] ?? ($_POST['id'] ?? ''));

if (!$id) {
    json_response(['success' => false, 'error' => 'Missing id.'], 400);
}

$ok = delete_project($id);
json_response(['success' => $ok]);
