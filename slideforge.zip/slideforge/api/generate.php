<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/pptx.php';
set_time_limit(900);

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$topic = trim((string)($input['topic'] ?? ''));
$slideCount = max(4, min(16, (int)($input['slideCount'] ?? 8)));
$style = in_array($input['style'] ?? '', ['Minimal','Bold','Corporate','Playful'], true) ? $input['style'] : 'Minimal';
if ($topic === '') json_response(['success'=>false,'error'=>'Please enter a topic.'],422);

try {
    $outline = generate_outline_with_gemini($topic, $slideCount, $style);
    $id = preg_replace('/[^a-zA-Z0-9_]/', '', uniqid('deck_', true));
    $imgDir = IMAGES_DIR . '/' . $id;
    if (!is_dir($imgDir) && !@mkdir($imgDir, 0775, true)) throw new Exception('Could not create the image directory.');

    $title = (string)($outline['title'] ?? $topic);
    $subtitle = (string)($outline['subtitle'] ?? '');
    $slides = $outline['slides'];

    // Generate the title visual too — this is the first slide of the real deck.
    $titlePath = $imgDir . '/slide-1.png';
    generate_slide_image_with_gemini($topic, ['title'=>$title,'visual_subject'=>$topic], $style, $titlePath, true);
    $titlePath = glob($imgDir . '/slide-1.*')[0] ?? $titlePath;
    $titleImage = 'presentations/images/' . $id . '/' . basename($titlePath);

    foreach ($slides as $i => &$slide) {
        $slide['bullets'] = array_values(array_filter((array)($slide['bullets'] ?? []), fn($v)=>trim((string)$v)!==''));
        $localBase = $imgDir . '/slide-' . ($i + 2) . '.png';
        generate_slide_image_with_gemini($topic, $slide, $style, $localBase, false);
        $generated = glob($imgDir . '/slide-' . ($i + 2) . '.*') ?: [];
        if (!$generated) throw new Exception('Gemini did not produce an image for slide ' . ($i + 1) . '.');
        $slide['image'] = 'presentations/images/' . $id . '/' . basename($generated[0]);
        $slide['image_local'] = $generated[0];
    }
    unset($slide);

    $pptxPath = PPTX_DIR . '/' . $id . '.pptx';
    generate_pptx($pptxPath, $title, $subtitle, $slides, style_palette($style), $titlePath);

    $recordSlides = $slides;
    array_unshift($recordSlides, [
        'heading'=>$title,
        'bullets'=>[],
        'image'=>$titleImage,
        'image_local'=>$titlePath,
        'titleSlide'=>true
    ]);
    file_put_contents(SLIDES_DIR . '/' . $id . '.json', json_encode(['title'=>$title,'subtitle'=>$subtitle,'slides'=>$recordSlides], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE), LOCK_EX);
    add_project(['id'=>$id,'topic'=>$topic,'title'=>$title,'slideCount'=>$slideCount+1,'style'=>$style,'createdAt'=>date('c'),'thumbnail'=>$titleImage]);
    json_response(['success'=>true,'id'=>$id,'viewUrl'=>'view.php?id='.$id,'downloadUrl'=>'download.php?id='.$id]);
} catch (Throwable $e) {
    json_response(['success'=>false,'error'=>$e->getMessage()], 502);
}
