<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle = 'Your projects — SlideForge';
$currentPage = 'projects';
$projects = read_projects();
include __DIR__ . '/includes/header.php';
?>
<section class="page-intro">
  <h1>Your projects</h1>
  <p>Every deck you've generated, saved locally as a real <code>.pptx</code> file.</p>
</section>

<section class="project-grid" id="downloads">
  <?php if (!$projects): ?>
    <div class="empty-state">
      <p>No decks yet.</p>
      <a href="index.php" class="btn-primary">Generate your first deck</a>
    </div>
  <?php endif; ?>

  <?php foreach ($projects as $p): ?>
    <article class="project-card project-card-full" data-project-id="<?= htmlspecialchars($p['id']) ?>">
      <a href="view.php?id=<?= urlencode($p['id']) ?>" class="project-thumb-link">
        <div class="project-thumb" style="background-image:url('<?= htmlspecialchars($p['thumbnail'] ?? '') ?>')"></div>
      </a>
      <div class="project-meta">
        <h3><?= htmlspecialchars($p['title']) ?></h3>
        <span><?= (int)$p['slideCount'] ?> slides &middot; <?= htmlspecialchars($p['style']) ?> &middot; <?= htmlspecialchars(date('M j, Y', strtotime($p['createdAt']))) ?></span>
        <div class="project-actions">
          <a href="view.php?id=<?= urlencode($p['id']) ?>" class="btn-ghost">View</a>
          <a href="download.php?id=<?= urlencode($p['id']) ?>" class="btn-ghost">Download</a>
          <button class="btn-ghost btn-danger" data-delete="<?= htmlspecialchars($p['id']) ?>" type="button">Delete</button>
        </div>
      </div>
    </article>
  <?php endforeach; ?>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
