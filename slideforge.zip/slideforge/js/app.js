(function () {
  "use strict";

  /* ---------------- Theme toggle ---------------- */
  var root = document.documentElement;
  var saved = localStorage.getItem("slideforge-theme");
  if (saved) root.setAttribute("data-theme", saved);

  var toggleBtn = document.getElementById("themeToggle");
  if (toggleBtn) {
    toggleBtn.addEventListener("click", function () {
      var next = root.getAttribute("data-theme") === "day" ? "night" : "day";
      root.setAttribute("data-theme", next);
      localStorage.setItem("slideforge-theme", next);
    });
  }

  /* ---------------- Generator form ---------------- */
  var form = document.getElementById("generateForm");
  if (form) {
    var progressMessages = [
      "Reading your topic\u2026",
      "Researching key points\u2026",
      "Structuring the outline\u2026",
      "Writing slide copy\u2026",
      "Sourcing images for each slide\u2026",
      "Laying out the deck\u2026",
      "Almost done\u2026",
    ];
    var progressPane = document.getElementById("progressPane");
    var progressMessage = document.getElementById("progressMessage");
    var errorEl = document.getElementById("formError");
    var btn = document.getElementById("generateBtn");
    var btnLabel = btn.querySelector(".btn-label");
    var btnSpinner = btn.querySelector(".btn-spinner");
    var msgTimer = null;

    function startProgress() {
      progressPane.hidden = false;
      var i = 0;
      progressMessage.textContent = progressMessages[0];
      msgTimer = setInterval(function () {
        i = (i + 1) % progressMessages.length;
        progressMessage.textContent = progressMessages[i];
      }, 1800);
    }
    function stopProgress() {
      clearInterval(msgTimer);
      progressPane.hidden = true;
    }

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      errorEl.hidden = true;

      var payload = {
        topic: document.getElementById("topic").value.trim(),
        slideCount: document.getElementById("slideCount").value,
        style: document.getElementById("style").value,
      };

      if (!payload.topic) {
        errorEl.textContent = "Please enter a topic first.";
        errorEl.hidden = false;
        return;
      }

      btn.disabled = true;
      btnLabel.textContent = "Generating\u2026";
      btnSpinner.hidden = false;
      startProgress();

      fetch("api/generate.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })
        .then(function (res) { return res.json().then(function (data) { return { ok: res.ok, data: data }; }); })
        .then(function (result) {
          if (!result.ok || !result.data.success) {
            throw new Error(result.data.error || "Something went wrong generating the deck.");
          }
          window.location.href = result.data.viewUrl;
        })
        .catch(function (err) {
          stopProgress();
          btn.disabled = false;
          btnLabel.textContent = "Generate deck";
          btnSpinner.hidden = true;
          errorEl.textContent = err.message;
          errorEl.hidden = false;
        });
    });
  }

  /* ---------------- Delete project ---------------- */
  document.querySelectorAll("[data-delete]").forEach(function (button) {
    button.addEventListener("click", function () {
      var id = button.getAttribute("data-delete");
      if (!confirm("Delete this deck? This can't be undone.")) return;
      fetch("api/delete.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: id }),
      })
        .then(function (res) { return res.json(); })
        .then(function (data) {
          if (data.success) {
            var card = button.closest("[data-project-id]");
            if (card) card.remove();
          }
        });
    });
  });

  /* ---------------- Slide viewer ---------------- */
  var stage = document.getElementById("slideStage");
  if (stage) {
    var slides = Array.prototype.slice.call(stage.querySelectorAll(".slide"));
    var railThumbs = Array.prototype.slice.call(document.querySelectorAll(".rail-thumb"));
    var positionLabel = document.getElementById("slidePosition");
    var current = 0;

    function show(index) {
      if (index < 0 || index >= slides.length) return;
      slides[current].classList.remove("active");
      railThumbs[current] && railThumbs[current].classList.remove("active");
      current = index;
      slides[current].classList.add("active");
      railThumbs[current] && railThumbs[current].classList.add("active");
      positionLabel.textContent = (current + 1) + " / " + slides.length;
    }

    document.getElementById("prevSlide").addEventListener("click", function () { show(current - 1); });
    document.getElementById("nextSlide").addEventListener("click", function () { show(current + 1); });
    railThumbs.forEach(function (thumb, i) {
      thumb.addEventListener("click", function () { show(i); });
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "ArrowRight") show(current + 1);
      if (e.key === "ArrowLeft") show(current - 1);
    });
  }
})();
