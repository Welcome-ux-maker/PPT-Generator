<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle = 'SlideForge — turn a topic into a deck';
$currentPage = 'generate';
$recent = array_slice(read_projects(), 0, 4);
include __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <div class="hero-copy">
    <p class="kicker">AI deck generator</p>
    <h1>Type a topic.<br>Walk away with a deck.</h1>
    <p class="lede">SlideForge asks Gemini to research and structure your topic, finds a
      relevant photo for every slide, and writes a real <code>.pptx</code> file you can
      open in PowerPoint, Keynote, or Google Slides.</p>
  </div>
  <div class="hero-art" aria-hidden="true">
    <div class="card-stack">
      <div class="card card-3"></div>
      <div class="card card-2"></div>
      <div class="card card-1">
        <span class="card-line w70"></span>
        <span class="card-line w40"></span>
        <span class="card-block"></span>
      </div>
    </div>
  </div>
</section>

<section class="generator-panel" id="generator">
  <form id="generateForm" novalidate>
    <label for="topic">Topic</label>
    <input type="text" id="topic" name="topic" placeholder="e.g. The future of solar energy in India" required autocomplete="off">

    <div class="field-row">
      <div class="field">
        <label for="slideCount">Slides</label>
        <select id="slideCount" name="slideCount">
          <option value="6">6</option>
          <option value="8" selected>8</option>
          <option value="10">10</option>
          <option value="12">12</option>
        </select>
      </div>
      <div class="field">
        <label for="style">Visual style</label>
        <select id="style" name="style">
          <option value="Minimal" selected>Minimal</option>
          <option value="Bold">Bold &amp; dark</option>
          <option value="Corporate">Corporate</option>
          <option value="Playful">Playful</option>
        </select>
      </div>
    </div>

    <button type="submit" id="generateBtn" class="btn-primary">
      <span class="btn-label">Generate deck</span>
      <span class="btn-spinner" hidden></span>
    </button>

    <p id="formError" class="form-error" hidden></p>
  </form>

  <div id="progressPane" class="progress-pane" hidden>
    <div class="progress-bar"><div class="progress-fill"></div></div>
    <p id="progressMessage">Reading your topic&hellip;</p>
  </div>
</section>

<?php if ($recent): ?>
<section class="recent-section">
  <div class="recent-heading">
    <h2>Recent decks</h2>
    <a href="projects.php">View all &rarr;</a>
  </div>
  <div class="project-grid project-grid-compact">
    <?php foreach ($recent as $p): ?>
      <a class="project-card" href="view.php?id=<?= urlencode($p['id']) ?>">
        <div class="project-thumb" style="background-image:url('<?= htmlspecialchars($p['thumbnail'] ?? '') ?>')"></div>
        <div class="project-meta">
          <h3><?= htmlspecialchars($p['title']) ?></h3>
          <span><?= (int)$p['slideCount'] ?> slides &middot; <?= htmlspecialchars(date('M j', strtotime($p['createdAt']))) ?></span>
        </div>
      </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
