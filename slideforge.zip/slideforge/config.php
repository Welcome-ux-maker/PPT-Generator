<?php
/**
 * SlideForge configuration
 * -------------------------------------------------------------
 * Fill in your own keys below. Nothing here talks to a database -
 * project metadata is kept in data/projects.json and every deck
 * is written straight to disk as a real .pptx file.
 */

// Required: get a free key at https://aistudio.google.com/apikey
define('GEMINI_API_KEY', 'You gemini api key');

// Any current Gemini text model works. gemini-2.0-flash is fast and cheap.
define('GEMINI_MODEL', 'gemini-3-flash-preview');
// Gemini also generates the slide images directly. No Pixabay/Pexels key is needed.
define('GEMINI_IMAGE_MODEL', 'gemini-3.1-flash-image');


// Gemini HTTPS configuration.
// If your local PHP installation does not have a CA bundle configured,
// cURL can report: "unable to get local issuer certificate".
// Keep verification enabled by default; the fallback below is only used
// for this specific local-certificate problem so the app can run on
// common Windows/XAMPP PHP installations.
define('GEMINI_ALLOW_INSECURE_SSL_FALLBACK', true);

// -------------------------------------------------------------
// Paths - you shouldn't need to touch these.
define('BASE_DIR', __DIR__);
define('DATA_DIR', BASE_DIR . '/data');
define('SLIDES_DIR', DATA_DIR . '/slides');
define('PPTX_DIR', BASE_DIR . '/presentations');
define('IMAGES_DIR', PPTX_DIR . '/images');
define('PPTX_TEMPLATE', BASE_DIR . '/pptx_template.pptx');
define('PROJECTS_FILE', DATA_DIR . '/projects.json');

// Make sure the working folders exist on first run.
foreach ([DATA_DIR, SLIDES_DIR, PPTX_DIR, IMAGES_DIR] as $dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
}
if (!file_exists(PROJECTS_FILE)) {
    file_put_contents(PROJECTS_FILE, json_encode([]));
}

date_default_timezone_set('UTC');
