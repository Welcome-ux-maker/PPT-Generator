<?php
$currentPage = $currentPage ?? '';
?>
<!DOCTYPE html>
<html lang="en" data-theme="night">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?? 'SlideForge' ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="noise-overlay" aria-hidden="true"></div>
<header class="site-header">
  <a href="index.php" class="brand">
    <span class="brand-mark">
      <svg width="26" height="26" viewBox="0 0 26 26" fill="none">
        <rect x="2" y="6" width="16" height="11" rx="1.5" fill="currentColor" opacity="0.35"/>
        <rect x="6" y="9" width="16" height="11" rx="1.5" fill="currentColor"/>
      </svg>
    </span>
    SlideForge
  </a>
  <nav class="main-nav">
    <a href="index.php" class="<?= $currentPage === 'generate' ? 'active' : '' ?>">Generate</a>
    <a href="projects.php" class="<?= $currentPage === 'projects' ? 'active' : '' ?>">Projects</a>
    <a href="projects.php#downloads" class="<?= $currentPage === 'downloads' ? 'active' : '' ?>">Downloads</a>
  </nav>
  <button id="themeToggle" class="theme-toggle" type="button" aria-label="Toggle day and night mode">
    <span class="icon-sun">☀</span>
    <span class="icon-moon">☾</span>
  </button>
</header>
<main class="site-main">
