</main>
<footer class="site-footer">
  <span>SlideForge &mdash; decks written on the fly by Gemini.</span>
</footer>
<script src="js/app.js"></script>
</body>
</html>
