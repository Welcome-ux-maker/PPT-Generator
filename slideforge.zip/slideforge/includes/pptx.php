<?php
/**
 * Dependency-free PPTX writer.
 * Uses a known-valid python-pptx package template as the Open XML base,
 * then replaces slide XML and adds Gemini-generated images.
 * No Composer / PHPPresentation required.
 */

function pptx_xml_escape(string $text): string {
    return htmlspecialchars($text, ENT_XML1 | ENT_QUOTES, 'UTF-8');
}

function pptx_text_shape(string $text, int $id, int $x, int $y, int $w, int $h, int $size, string $color, bool $bold = false): string {
    $safe = pptx_xml_escape($text);
    $b = $bold ? ' b="1"' : '';
    return '<p:sp><p:nvSpPr><p:cNvPr id="'.$id.'" name="Text '.$id.'"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
        . '<p:spPr><a:xfrm><a:off x="'.$x.'" y="'.$y.'"/><a:ext cx="'.$w.'" cy="'.$h.'"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>'
        . '<p:txBody><a:bodyPr wrap="square"><a:spAutoFit/></a:bodyPr><a:lstStyle/><a:p><a:pPr/><a:r><a:rPr lang="en-US" sz="'.($size*100).'"'.$b.'><a:solidFill><a:srgbClr val="'.$color.'"/></a:solidFill><a:latin typeface="Aptos"/></a:rPr><a:t>'.$safe.'</a:t></a:r></a:p></p:txBody></p:sp>';
}

function pptx_bullets_shape(array $bullets, int $id, int $x, int $y, int $w, int $h, int $size, string $color): string {
    $paras = '';
    foreach ($bullets as $bullet) {
        $safe = pptx_xml_escape((string)$bullet);
        $paras .= '<a:p><a:pPr marL="260000" indent="-130000"><a:buChar char="•"/></a:pPr>'
            . '<a:r><a:rPr lang="en-US" sz="'.($size*100).'"><a:solidFill><a:srgbClr val="'.$color.'"/></a:solidFill><a:latin typeface="Aptos"/></a:rPr><a:t>'.$safe.'</a:t></a:r></a:p>';
    }
    return '<p:sp><p:nvSpPr><p:cNvPr id="'.$id.'" name="Body '.$id.'"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
        . '<p:spPr><a:xfrm><a:off x="'.$x.'" y="'.$y.'"/><a:ext cx="'.$w.'" cy="'.$h.'"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>'
        . '<p:txBody><a:bodyPr wrap="square"><a:spAutoFit/></a:bodyPr><a:lstStyle/>'.$paras.'</p:txBody></p:sp>';
}

function pptx_panel(int $id, int $x, int $y, int $w, int $h, string $color='0B1220', int $alpha=65000): string {
    return '<p:sp><p:nvSpPr><p:cNvPr id="'.$id.'" name="Panel '.$id.'"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
        . '<p:spPr><a:xfrm><a:off x="'.$x.'" y="'.$y.'"/><a:ext cx="'.$w.'" cy="'.$h.'"/></a:xfrm><a:prstGeom prst="roundRect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="'.$color.'"><a:alpha val="'.$alpha.'"/></a:srgbClr></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr></p:sp>';
}

function pptx_accent_bar(int $id, int $x, int $y, int $w, int $h, string $color): string {
    return '<p:sp><p:nvSpPr><p:cNvPr id="'.$id.'" name="Accent"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
        . '<p:spPr><a:xfrm><a:off x="'.$x.'" y="'.$y.'"/><a:ext cx="'.$w.'" cy="'.$h.'"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="'.$color.'"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr></p:sp>';
}

function pptx_image_shape(string $rid, int $id): string {
    // 13.333 x 7.5 inches, 16:9.
    return '<p:pic><p:nvPicPr><p:cNvPr id="'.$id.'" name="Gemini Visual '.$id.'"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr>'
        . '<p:blipFill><a:blip r:embed="'.$rid.'"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>'
        . '<p:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="12191999" cy="6858000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>';
}

function pptx_slide_xml(array $slide, string $title, string $subtitle, array $palette, bool $titleSlide, string $imageRid): string {
    $headingColor = $palette['heading'];
    $bodyColor = $palette['body'];
    $accent = $palette['accent'];
    $heading = $titleSlide ? $title : (string)($slide['heading'] ?? '');
    $bullets = $titleSlide ? [] : array_slice(array_values($slide['bullets'] ?? []), 0, 5);
    $num = (int)($slide['_number'] ?? 1);

    $shapes = pptx_image_shape($imageRid, 2);
    // Strong dark glass panel keeps generated visual and editable text readable.
    $panelX = 520000; $panelY = 620000; $panelW = $titleSlide ? 6500000 : 5750000; $panelH = 5600000;
    $shapes .= pptx_panel(3, $panelX, $panelY, $panelW, $panelH, '07111F', 66000);
    $shapes .= pptx_accent_bar(4, 820000, 980000, 720000, 70000, $accent);
    $label = $titleSlide ? 'SLIDEFORGE • GEMINI PRESENTATION' : sprintf('%02d  •  %s', $num, strtoupper((string)($slide['heading'] ?? '')));
    $shapes .= pptx_text_shape($label, 5, 820000, 1140000, 5200000, 360000, 11, $accent, true);
    $shapes .= pptx_text_shape($heading, 6, 820000, $titleSlide ? 1800000 : 1550000, 5200000, $titleSlide ? 1700000 : 1050000, $titleSlide ? 33 : 25, $headingColor, true);

    if ($titleSlide) {
        if ($subtitle !== '') $shapes .= pptx_text_shape($subtitle, 7, 820000, 3750000, 5000000, 800000, 1500, $bodyColor, false);
        $shapes .= pptx_text_shape('Generated with Gemini • Visuals by Nano Banana 2', 8, 820000, 5150000, 5000000, 350000, 9, $bodyColor, false);
    } else {
        $shapes .= pptx_bullets_shape($bullets, 7, 820000, 2700000, 5100000, 2850000, count($bullets) >= 5 ? 12 : 13, $bodyColor);
        $shapes .= pptx_text_shape((string)$num, 8, 11200000, 6250000, 350000, 250000, 900, 'FFFFFF', false);
    }

    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        . '<p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/>'.$shapes.'</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>';
}

function pptx_slide_rels(string $imageFile): string {
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout7.xml"/>'
        . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/'.pptx_xml_escape($imageFile).'"/>'
        . '</Relationships>';
}

function pptx_presentation_ids(int $count): string {
    $s = '';
    for ($i=1; $i<=$count; $i++) $s .= '<p:sldId id="'.(255+$i).'" r:id="'.($i===1 ? 'rId7' : 'rId'.(6+$i)).'"/>';
    return $s;
}

function pptx_add_png_default(string $xml): string {
    if (strpos($xml, 'Extension="png"') === false) {
        $xml = str_replace('<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">', '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="png" ContentType="image/png"/>', $xml);
    }
    return $xml;
}

function generate_pptx(string $path, string $title, string $subtitle, array $slides, array $palette, string $titleImage): void {
    if (!is_file(PPTX_TEMPLATE)) throw new Exception('PowerPoint template is missing: pptx_template.pptx');
    if (!is_file($titleImage)) throw new Exception('Title Gemini image is missing.');

    $all = [];
    $all[] = ['title'=>$title,'subtitle'=>$subtitle,'image_local'=>$titleImage,'titleSlide'=>true,'_number'=>1];
    foreach ($slides as $i=>$s) { $s['_number']=$i+2; $all[]=$s; }
    $count = count($all);

    $tmp = sys_get_temp_dir() . '/slideforge_ppt_' . bin2hex(random_bytes(6));
    if (!@mkdir($tmp, 0775, true)) throw new Exception('Could not create temporary PowerPoint directory.');
    if (class_exists('ZipArchive')) {
        $zip = new ZipArchive();
        if ($zip->open(PPTX_TEMPLATE) !== true) throw new Exception('Could not open PowerPoint template.');
        if (!$zip->extractTo($tmp)) { $zip->close(); throw new Exception('Could not extract PowerPoint template.'); }
        $zip->close();
    } else {
        $unzip = trim((string)@shell_exec('command -v unzip 2>/dev/null'));
        if ($unzip === '') throw new Exception('PHP Zip extension is disabled and the unzip command is unavailable. Enable extension=zip in php.ini.');
        $cmd = escapeshellarg($unzip).' -q '.escapeshellarg(PPTX_TEMPLATE).' -d '.escapeshellarg($tmp);
        @exec($cmd, $out, $status);
        if ($status !== 0) throw new Exception('Could not extract the PowerPoint template.');
    }

    // Make the presentation 16:9.
    $presPath = $tmp.'/ppt/presentation.xml';
    $pres = file_get_contents($presPath);
    $pres = str_replace('type="screen4x3"', 'type="screen16x9"', $pres);
    $pres = preg_replace('/<p:sldIdLst>.*?<\/p:sldIdLst>/s', '<p:sldIdLst>'.pptx_presentation_ids($count).'</p:sldIdLst>', $pres, 1);
    file_put_contents($presPath, $pres);

    // Add slide relationships to the existing valid presentation package.
    $presRelsPath = $tmp.'/ppt/_rels/presentation.xml.rels';
    $presRels = file_get_contents($presRelsPath);
    for ($i=2; $i<=$count; $i++) {
        $rid = 'rId'.(6+$i);
        $presRels = str_replace('</Relationships>', '<Relationship Id="'.$rid.'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide'.$i.'.xml"/></Relationships>', $presRels);
    }
    file_put_contents($presRelsPath, $presRels);

    // Content types: retain template parts and add slide overrides + PNG.
    $ctPath = $tmp.'/[Content_Types].xml';
    $ct = pptx_add_png_default(file_get_contents($ctPath));
    for ($i=2; $i<=$count; $i++) {
        $ct = str_replace('</Types>', '<Override PartName="/ppt/slides/slide'.$i.'.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/></Types>', $ct);
    }
    file_put_contents($ctPath, $ct);

    // Update core title.
    $core = $tmp.'/docProps/core.xml';
    if (is_file($core)) {
        $coreXml = file_get_contents($core);
        $coreXml = preg_replace('/<dc:title>.*?<\/dc:title>/s', '<dc:title>'.pptx_xml_escape($title).'</dc:title>', $coreXml, 1);
        file_put_contents($core, $coreXml);
    }

    // Generate/replace every slide. Slide 1 already exists in the template.
    foreach ($all as $idx=>$slide) {
        $num = $idx+1;
        $image = $slide['image_local'] ?? '';
        if (!is_file($image)) throw new Exception('Missing Gemini image for slide '.$num.'.');
        $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        if (!in_array($ext,['png','jpg','jpeg'],true)) throw new Exception('Unsupported slide image format on slide '.$num.'.');
        $mediaExt = $ext === 'jpeg' ? 'jpg' : $ext;
        $mediaName = 'slide'.$num.'.'.$mediaExt;
        @copy($image, $tmp.'/ppt/media/'.$mediaName);
        file_put_contents($tmp.'/ppt/slides/slide'.$num.'.xml', pptx_slide_xml($slide, $title, $subtitle, $palette, $idx===0, 'rId2'));
        file_put_contents($tmp.'/ppt/slides/_rels/slide'.$num.'.xml.rels', pptx_slide_rels($mediaName));
        if ($mediaExt !== 'png') {
            // The template already declares jpeg. JPG uses the same content type default.
        }
    }

    // Package everything into a fresh PPTX.
    @unlink($path);
    if (class_exists('ZipArchive')) {
        $out = new ZipArchive();
        if ($out->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) throw new Exception('Could not create the PowerPoint output.');
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tmp, FilesystemIterator::SKIP_DOTS));
        foreach ($it as $file) if ($file->isFile()) {
            $local = str_replace(DIRECTORY_SEPARATOR, '/', substr($file->getPathname(), strlen($tmp)+1));
            $out->addFile($file->getPathname(), $local);
        }
        if (!$out->close()) throw new Exception('PowerPoint package creation failed.');
    } else {
        $zipBin = trim((string)@shell_exec('command -v zip 2>/dev/null'));
        if ($zipBin === '') throw new Exception('PHP Zip extension is disabled and the zip command is unavailable. Enable extension=zip in php.ini.');
        $old = getcwd(); chdir($tmp);
        @exec(escapeshellarg($zipBin).' -q -r '.escapeshellarg($path).' .', $outLines, $status);
        chdir($old);
        if ($status !== 0) throw new Exception('Could not package the PowerPoint output.');
    }
    if (!is_file($path) || filesize($path) < 10000) throw new Exception('PowerPoint package creation failed.');

    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tmp, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($it as $file) { if ($file->isDir()) @rmdir($file->getPathname()); else @unlink($file->getPathname()); }
    @rmdir($tmp);
}
