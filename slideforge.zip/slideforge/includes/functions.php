<?php
require_once __DIR__ . '/../config.php';

function json_response($data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function read_projects(): array
{
    $raw = @file_get_contents(PROJECTS_FILE);
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function write_projects(array $projects): void
{
    file_put_contents(PROJECTS_FILE, json_encode(array_values($projects), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
}

function find_project(string $id): ?array
{
    foreach (read_projects() as $p) if (($p['id'] ?? '') === $id) return $p;
    return null;
}

function add_project(array $project): void
{
    $projects = read_projects();
    array_unshift($projects, $project);
    write_projects($projects);
}

function delete_project(string $id): bool
{
    $projects = read_projects();
    $kept = [];
    $found = false;
    foreach ($projects as $p) {
        if (($p['id'] ?? '') === $id) {
            $found = true;
            @unlink(PPTX_DIR . '/' . $id . '.pptx');
            @unlink(SLIDES_DIR . '/' . $id . '.json');
            $imgDir = IMAGES_DIR . '/' . $id;
            if (is_dir($imgDir)) {
                foreach (glob($imgDir . '/*') ?: [] as $f) @unlink($f);
                @rmdir($imgDir);
            }
            continue;
        }
        $kept[] = $p;
    }
    write_projects($kept);
    return $found;
}

function slugify(string $text): string
{
    $text = preg_replace('/[^a-zA-Z0-9]+/', '-', strtolower(trim($text)));
    return trim($text, '-') ?: 'deck';
}

/** Reliable Gemini JSON HTTP helper for XAMPP/Windows. */
function curl_post_json_internal(string $url, array $body, array $headers, int $timeoutSeconds, bool $verifySsl = true): array
{
    if (!function_exists('curl_init')) {
        throw new Exception('PHP cURL is required. Enable extension=curl in php.ini.');
    }
    $json = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) throw new Exception('Could not encode the Gemini request.');

    $ch = curl_init($url);
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => array_merge(['Content-Type: application/json', 'Accept: application/json'], $headers),
        CURLOPT_POSTFIELDS => $json,
        CURLOPT_CONNECTTIMEOUT => 20,
        CURLOPT_TIMEOUT => $timeoutSeconds,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => $verifySsl,
        CURLOPT_SSL_VERIFYHOST => $verifySsl ? 2 : 0,
    ];
    if (defined('GEMINI_CAINFO') && GEMINI_CAINFO !== '' && is_file(GEMINI_CAINFO)) {
        $opts[CURLOPT_CAINFO] = GEMINI_CAINFO;
    }
    curl_setopt_array($ch, $opts);
    $response = curl_exec($ch);
    $errno = curl_errno($ch);
    $error = curl_error($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return [$response, $errno, $error, $status];
}

function http_post_json_with_headers(string $url, array $body, array $headers = [], int $timeoutSeconds = 120): string
{
    [$response, $errno, $err, $status] = curl_post_json_internal($url, $body, $headers, $timeoutSeconds, true);
    if ($response === false && defined('GEMINI_ALLOW_INSECURE_SSL_FALLBACK') && GEMINI_ALLOW_INSECURE_SSL_FALLBACK && in_array($errno, [35, 51, 58, 60], true)) {
        [$response, $errno, $err, $status] = curl_post_json_internal($url, $body, $headers, $timeoutSeconds, false);
    }
    if ($response === false) throw new Exception('Network error contacting Gemini: ' . ($err ?: 'cURL error ' . $errno));
    if ($status >= 400) {
        $decoded = json_decode($response, true);
        $message = $decoded['error']['message'] ?? trim($response);
        if ($status === 429) $message .= ' — Gemini quota/rate limit reached. Check your Google AI Studio project quota/billing.';
        throw new Exception('Gemini HTTP error ' . $status . ': ' . $message);
    }
    return $response;
}

function http_post_json(string $url, array $body, int $timeoutSeconds = 120): string
{
    return http_post_json_with_headers($url, $body, [], $timeoutSeconds);
}

function gemini_url(string $model): string
{
    return 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent';
}

function generate_outline_with_gemini(string $topic, int $slideCount, string $style): array
{
    if (GEMINI_API_KEY === '' || strpos(GEMINI_API_KEY, 'PASTE_YOUR') === 0) {
        throw new Exception('Add your Gemini API key in config.php before generating a deck.');
    }

    $prompt = <<<PROMPT
Create a premium, factual {$slideCount}-slide presentation about "{$topic}".
The requested visual direction is {$style}.

Return ONLY JSON with this exact structure:
{
  "title":"...",
  "subtitle":"...",
  "slides":[
    {
      "heading":"...",
      "bullets":["...","...","..."],
      "speaker_notes":"...",
      "visual_subject":"..."
    }
  ]
}

Content rules:
- Exactly {$slideCount} content slides.
- Slide 1 introduces the topic; final slide is a strong conclusion/takeaway.
- 3-5 concise bullets per slide, each preferably under 14 words.
- Avoid generic filler and repetition.
- Make facts specific and useful.
- "visual_subject" must be a concrete visual concept unique to that slide.
- Do not put image instructions into the bullets.
PROMPT;

    $body = [
        'contents' => [[ 'parts' => [[ 'text' => $prompt ]] ]],
        'generationConfig' => [
            'temperature' => 0.55,
            'responseMimeType' => 'application/json'
        ],
        'tools' => [[ 'googleSearch' => new stdClass() ]]
    ];

    $raw = http_post_json_with_headers(gemini_url(GEMINI_MODEL), $body, ['x-goog-api-key: ' . GEMINI_API_KEY], 120);
    $decoded = json_decode($raw, true);
    $text = $decoded['candidates'][0]['content']['parts'][0]['text'] ?? '';
    if ($text === '') throw new Exception('Gemini returned no presentation content.');

    $text = trim(preg_replace('/^```(?:json)?|```$/i', '', trim($text)));
    $outline = json_decode($text, true);
    if (!is_array($outline) || empty($outline['slides'])) throw new Exception('Gemini returned invalid presentation JSON.');

    $outline['slides'] = array_slice($outline['slides'], 0, $slideCount);
    if (count($outline['slides']) !== $slideCount) throw new Exception('Gemini returned the wrong number of slides.');
    return $outline;
}

/**
 * Generate a real 16:9 visual with Gemini Nano Banana 2.
 * The visual is deliberately composed like a premium presentation background,
 * leaving clean negative space for the editable PowerPoint text layer.
 */
function generate_slide_image_with_gemini(string $topic, array $slide, string $style, string $localPath, bool $titleSlide = false): void
{
    if (!extension_loaded('curl')) throw new Exception('PHP cURL is required for Gemini image generation.');
    if (GEMINI_API_KEY === '' || strpos(GEMINI_API_KEY, 'PASTE_YOUR') === 0) throw new Exception('Gemini API key is missing.');

    $heading = trim((string)($slide['heading'] ?? $slide['title'] ?? $topic));
    $visual = trim((string)($slide['visual_subject'] ?? $slide['image_query'] ?? $topic));

    if ($titleSlide) {
        $prompt = "Create a premium cinematic 16:9 presentation hero image for a deck titled '{$heading}' about {$topic}. Visual subject: {$visual}. Style: {$style}. Use a sophisticated editorial composition, realistic/high-end imagery, depth, subtle gradients, strong focal point on the right side, and generous clean negative space on the left for editable title text. No logos, no watermark, no UI, no borders, no slide frame, no readable text. The result must look like a professionally art-directed Gemini/Nano Banana presentation visual, not a stock-photo collage.";
    } else {
        $prompt = "Create a premium 16:9 presentation visual for a slide titled '{$heading}' in a deck about {$topic}. Visual subject: {$visual}. Style: {$style}. Create an art-directed, high-end editorial scene/illustration/infographic-like composition appropriate to the subject. Put the main visual interest toward the right 55% of the canvas and keep the left 40% clean enough for editable overlay text. Use realistic detail where appropriate, elegant lighting, depth, restrained color treatment, and strong visual hierarchy. No logos, no watermark, no UI, no borders, no slide frame, and no readable text.";
    }

    $body = [
        'contents' => [[ 'parts' => [[ 'text' => $prompt ]] ]],
        'generationConfig' => [
            'responseModalities' => ['IMAGE'],
            'responseFormat' => [
                'image' => [
                    'aspectRatio' => '16:9',
                    'imageSize' => '2K'
                ]
            ]
        ]
    ];

    $raw = http_post_json_with_headers(gemini_url(GEMINI_IMAGE_MODEL), $body, ['x-goog-api-key: ' . GEMINI_API_KEY], 180);
    $decoded = json_decode($raw, true);
    $parts = $decoded['candidates'][0]['content']['parts'] ?? [];
    $imageData = null;
    $mime = 'image/png';
    foreach ($parts as $part) {
        if (!empty($part['inlineData']['data'])) {
            $imageData = $part['inlineData']['data'];
            $mime = $part['inlineData']['mimeType'] ?? $mime;
            break;
        }
    }
    if (!$imageData) throw new Exception('Gemini image model returned no image data.');

    $bytes = base64_decode($imageData, true);
    if ($bytes === false || strlen($bytes) < 1000) throw new Exception('Gemini returned invalid image data.');
    $ext = stripos($mime, 'jpeg') !== false || stripos($mime, 'jpg') !== false ? '.jpg' : '.png';
    $finalPath = preg_replace('/\.(png|jpe?g)$/i', $ext, $localPath);
    if (@file_put_contents($finalPath, $bytes) === false) throw new Exception('Could not save generated Gemini image.');
    if ($finalPath !== $localPath) {
        @unlink($localPath);
        $localPath = $finalPath;
    }
}

function style_palette(string $style): array
{
    $palettes = [
        'Minimal'   => ['bg' => '111827', 'heading' => 'FFFFFF', 'body' => 'F3F4F6', 'accent' => 'A78BFA'],
        'Bold'      => ['bg' => '160D24', 'heading' => 'FFFFFF', 'body' => 'F5EFFF', 'accent' => 'F59E0B'],
        'Corporate' => ['bg' => '0B1220', 'heading' => 'FFFFFF', 'body' => 'E5E7EB', 'accent' => '60A5FA'],
        'Playful'   => ['bg' => '26100B', 'heading' => 'FFFFFF', 'body' => 'FFF7ED', 'accent' => 'FB7185'],
    ];
    return $palettes[$style] ?? $palettes['Minimal'];
}
