<?php
require_once __DIR__ . '/includes/functions.php';

$id = $_GET['id'] ?? '';
$project = $id ? find_project($id) : null;
$slidesPath = SLIDES_DIR . '/' . basename($id) . '.json';

if (!$project || !file_exists($slidesPath)) {
    http_response_code(404);
    $pageTitle = 'Deck not found — SlideForge';
    $currentPage = '';
    include __DIR__ . '/includes/header.php';
    echo '<section class="page-intro"><h1>We couldn\'t find that deck</h1>
          <p><a href="projects.php">Back to your projects</a></p></section>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

$deck = json_decode(file_get_contents($slidesPath), true);
$pageTitle = htmlspecialchars($deck['title']) . ' — SlideForge';
$currentPage = 'projects';
include __DIR__ . '/includes/header.php';
?>
<section class="viewer">
  <div class="viewer-toolbar">
    <div>
      <h1><?= htmlspecialchars($deck['title']) ?></h1>
      <p class="viewer-sub"><?= htmlspecialchars($deck['subtitle'] ?? '') ?></p>
    </div>
    <a href="download.php?id=<?= urlencode($id) ?>" class="btn-primary btn-small">
      <span class="btn-label">Download .pptx</span>
    </a>
  </div>

  <div class="viewer-body">
    <aside class="slide-rail" id="slideRail">
      <?php foreach ($deck['slides'] as $i => $s): ?>
        <button class="rail-thumb <?= $i === 0 ? 'active' : '' ?>" data-index="<?= $i ?>" type="button">
          <span class="rail-index"><?= $i + 1 ?></span>
          <span class="rail-title"><?= htmlspecialchars($s['heading']) ?></span>
        </button>
      <?php endforeach; ?>
    </aside>

    <div class="slide-stage-wrap">
      <div class="slide-stage" id="slideStage">
        <?php foreach ($deck['slides'] as $i => $s): ?>
          <div class="slide <?= $i === 0 ? 'active' : '' ?>" data-index="<?= $i ?>">
            <div class="slide-text">
              <h2><?= htmlspecialchars($s['heading']) ?></h2>
              <ul>
                <?php foreach ($s['bullets'] as $b): ?>
                  <li><?= htmlspecialchars($b) ?></li>
                <?php endforeach; ?>
              </ul>
            </div>
            <?php if (!empty($s['image'])): ?>
              <div class="slide-image" style="background-image:url('<?= htmlspecialchars($s['image']) ?>')"></div>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
      <div class="slide-controls">
        <button id="prevSlide" type="button" aria-label="Previous slide">&larr;</button>
        <span id="slidePosition">1 / <?= count($deck['slides']) ?></span>
        <button id="nextSlide" type="button" aria-label="Next slide">&rarr;</button>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
